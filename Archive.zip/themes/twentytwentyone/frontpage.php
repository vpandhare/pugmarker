<?php //Template name: fornt page?>
<?php get_header();?>
    <header>
      <div class="customcontainer">
        <nav class="navbar navbar-expand-lg navbar-light navbarcustom">
          <div class="container-fluid">
            <a class="navbar-brand" href="#"
              ><img src="./assets/imgaes/LOGO.svg" alt=""
            /></a>
            <div class="leftdivnav">
                <button class="btn">  <img src="./assets/imgaes/loginicon.svg" alt="loginicon" /></button>
                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"><img src="./assets/imgaes/mblicon.svg" alt="mblicon"></span>
                </button>
            </div>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto cutomeul mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#"
                    >Home</a
                  >
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">About Us</a>
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Courses & Tours
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#">Action</a></li>
                    <li>
                      <a class="dropdown-item" href="#">Another action</a>
                    </li>
                    <li><hr class="dropdown-divider" /></li>
                    <li>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle"
                    href="#"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Services
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#">Action</a></li>
                    <li>
                      <a class="dropdown-item" href="#">Another action</a>
                    </li>
                    <li><hr class="dropdown-divider" /></li>
                    <li>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#"
                    >Contact Us</a
                  >
                </li>
              </ul>
              <div class="d-flex">
                <button class="btn" type="submit">
                  <img src="./assets/imgaes/loginicon.svg" alt="loginicon" />
                  <span>login</span>
                </button>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>

    <section class="blogssection">
      <div class="customcontainer">
        <h2 class="heading">Upcoming Import-Export Courses & Tours</h2>
        <div class="row mt-md-5">
          <div class="col-lg-6">
            <div class="mainblogs">
              <div class="img-div">
                <img src="./assets/imgaes/DJI_0059.png" alt="DJI_0059" />
                <div class="cources">Offline Course</div>
              </div>
              <div class="content-div">
                <h3 class="blogheading">Learn Import-Export In-Person</h3>
                <p>
                  You can learn from the practitioners themselves & start your
                  business even if you have no experience, less budget, & no
                  products.
                </p>
                <div class="row">
                  <div class="col-md-6">
                    <div class="location">
                      <span class=""
                        ><img
                          src="./assets/imgaes/locationicon.svg"
                          alt="locationicon"
                        />Pune</span
                      >
                    </div>
                    <div class="date">
                      <span>29th Jul - 2nd Aug 22</span><span>8AM - 2PM</span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="location">
                      <span class=""
                        ><img
                          src="./assets/imgaes/locationicon.svg"
                          alt="locationicon"
                        />Mumbai</span
                      >
                    </div>
                    <div class="date">
                      <span>31st Jul - 4th Aug 22</span><span>10AM - 4PM</span>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="location">
                      <span
                        ><img
                          src="./assets/imgaes/locationicon.svg"
                          alt="locationicon"
                        />
                        <span class="aval">Available on</span> 2 more
                        locations</span
                      >
                    </div>
                    <div class="divbtn">
                      <button class="btn">Book Now</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="mainblogs">
              <div class="img-div">
                <img src="./assets/imgaes/Untitled-3-01.png" alt="DJI_0059" />
                <div class="cources green">Offline Course</div>
              </div>
              <div class="content-div">
                <h3 class="blogheading">
                  Advanced Online Import-Export Training
                </h3>
                <p>
                  Online Import-Export Course with hand-holding, practical
                  guidance, & opportunity to connect with Dubai Partners.
                </p>
                <div class="row">
                  <div class="locationbtncn">
                    <div class="col-12">
                      <div class="date forbord">
                        <span class="newone"
                          ><img src="./assets/imgaes/dateicon.svg" alt="" />
                          29th Jul - 8th Aug 22 , 6PM - 9PM</span
                        >
                      </div>
                    </div>

                    <div class="col-12">
                      <div class="divbtn">
                        <button class="btn">Book Now</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row mt-md-5">
          <div class="col-lg-4">
            <div class="mainblogs">
              <div class="img-div">
                <img src="./assets/imgaes/Untitled-1.png" alt="DJI_0059" />
                <div class="cources green">Live Webinar</div>
              </div>
              <div class="content-div">
                <h3 class="blogheading">
                  How to Start an Import-Export Business?
                </h3>
                <p>
                  Attend our 1-hour live webinar & explore what is import-export
                  and how you can start your own entrepreneurial journey in it.
                </p>
                <div class="row">
                  <div class="col-12">
                    <div class="date forbord">
                      <span class="newone"
                        ><img src="./assets/imgaes/dateicon.svg" alt="" />
                        Everyday, 8PM - 10PM</span
                      >
                    </div>
                  </div>
                  <div class="divbtn">
                    <button class="btn">Book Now</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="mainblogs">
              <div class="img-div">
                <img src="./assets/imgaes/jnpt_fb2.png" alt="DJI_0059" />
                <div class="cources">Location Tour</div>
              </div>
              <div class="content-div">
                <h3 class="blogheading">
                  Practical JNPT Tour Benefited by 1000+ Exporters
                </h3>
                <p>
                  Experience live exporting of goods & get practical exposure to
                  all the important JNPT Operations during our Tour.
                </p>
                <div class="row">
                  <div class="col-12">
                    <div class="date forbord">
                      <span class="newone"
                        ><img src="./assets/imgaes/locationicon.svg" alt="" />
                        <span>Navi Mumbai</span> 31st Jul 22 10AM - 6PM</span
                      >
                    </div>
                    <div class="divbtn">
                      <button class="btn">Book Now</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="mainblogs">
              <div class="img-div">
                <img
                  src="./assets/imgaes/IMG_20220523_104617310.png"
                  alt="DJI_0059"
                />
                <div class="cources">Location Tour</div>
              </div>
              <div class="content-div">
                <h3 class="blogheading">5-Days Dubai Business Tour</h3>
                <p>
                  Get to meet Dubai Buyers as well as Importers from 194
                  countries. A tour where you can pitch buyers directly!
                </p>
                <div class="row">
                  <div class="col-12">
                    <div class="date forbord">
                      <span class="newone"
                        ><img src="./assets/imgaes/locationicon.svg" alt="" />
                        <span>Dubai,</span> 31st Jul - 04th Aug 22</span
                      >
                    </div>
                    <div class="divbtn">
                      <button class="btn">Book Now</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 mt-md-5">
            <div class="btndiv">
                <button class="btn viewmore">View All</button>
            </div>
          </div>
        </div>
        
      </div>
    </section>

    <section class="whatwillgetformsection">
        <div class="customcontainer">
            <div class="row">
                <div class="col-lg-4">
                    <h1 class="lefrcontent">What Will You Get From Here?</h1>
                </div>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-6">
                            <div class="supportmain">
                                <img src="./assets/imgaes/support1.png" alt="support1">
                                <p>Guaranteed Support For 1st Import/Export</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support2.png" alt="support2">
                                <p>Factual Insights through First-Hand Experiences</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support3.png" alt="support3">
                                <p>Export Estimation, Banking & Risk Management</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support7.png" alt="support7">
                                <p>Export Estimation, Banking & Risk Management</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="supportmain">
                                <img src="./assets/imgaes/support4.png" alt="support4">
                                <p>Dominate the End-to-End Export Cycle</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support5.png" alt="support5">
                                <p>Smooth Documentation & Licensing Process</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support6.png" alt="support6">
                                <p>Worry-Free Custom Clearance Procedure</p>
                            </div>
                            <div class="supportmain">
                                <img src="./assets/imgaes/support7.png" alt="support7">
                                <p>Worry-Free Custom Clearance Procedure</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="planmainsection">
        <div class="customcontainer ">
            <div class="backsection">
                <div class="row">
                    <div class="col-md-12">
                        <div class="headingplan">
                            <h2>You Will Also Get Access to a 100 Days Action Plan</h2>
                            <p>That Guarantees Export with the Success Rate of 100%</p>
                        </div>
                    </div>
                    <div class="col-md-11 mt-md-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="traningstap">
                                    <div class="frist">
                                        01
                                    </div>
                                    <div class="content">
                                        <p>Enroll for Online/Offline Import Export training</p>
                                    </div>
                                    <div class="abimg">
                                        <img src="./assets/imgaes/arrowplan.svg" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="traningstap">
                                    <div class="frist ligt">
                                        02
                                    </div>
                                    <div class="content">
                                        <p>Complete the Training & Assignments</p>
                                    </div>
                                    <div class="abimg">
                                        <img src="./assets/imgaes/arrowplan.svg" alt="">
                                    </div>
                                </div>
                               
                            </div>
                            <div class="col-md-4">
                                <div class="traningstap">
                                    <div class="frist greenl">
                                        03
                                    </div>
                                    <div class="content">
                                        <p>Execute your first successful export with the 100 Days Action Plan</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mt-md-5">
                        <div class="btndiv widthbtn">
                            <button class="btn viewmore">Start Your Journey</button>
                        </div>
                </div>
            </div>
            
        </div>
    </section>
    <footer>
        <div class="copyright">© All rights reserved at Import Export Federation</div>
    </footer>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
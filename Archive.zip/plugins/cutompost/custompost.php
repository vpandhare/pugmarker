

<?php
/**
* Plugin Name: companyinfo
* Plugin URI: http://yourdomain.com
* Description: Insert a brief description of what your plugin does here.
* Version: 1.0.0
* Author: Your Name
* Author URI: http://yourdomain.com
* License: GPL2
*/

require_once(ABSPATH . 'wp-admin/includes/file.php');

add_action( 'init', function() {
    $args = [
        'public' => true,
        'label' => 'Company',
        "supports" => [ "title", "editor", "thumbnail", "excerpt",  "revisions", "position" ],
        "menu_icon" => "dashicons-welcome-learn-more",
        'show_in_rest' => true, // Enable REST API support
        'custom_fields' => array(
            array(
                'name' => 'location',
                'id' => 'location',
                'type' => 'text', // field type
                'show_in_rest' => true,
            ),
           
        )
   
    ];

    register_post_type( 'companyinfo', $args );
});


add_action( 'save_post', function( $post_id ) {
    // Check if our nonce is set.
    
    if ( ! isset( $_POST['companyinfo_custom_fields_nonce'] ) ) {
        return $post_id;
    }

    $nonce = $_POST['companyinfo_custom_fields_nonce'];

    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $nonce, 'companyinfo_custom_fields' ) ) {
        return $post_id;
    }

    // Check if this is an autosave.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }

    // Check the user's permissions.
    if ( 'companyinfo' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return $post_id;
        }
    } else {
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
        }
    }

    // Save the custom field data.
    if ( isset( $_POST['location'] ) ) {
        update_post_meta( $post_id, 'location', sanitize_text_field( $_POST['location'] ) );
    }
    if ( isset( $_POST['date'] ) ) {
        // update_post_meta( $post_id, 'date', floatval( $_POST['date'] ) );
        update_post_meta( $post_id, 'date', sanitize_text_field( $_POST['date'] ) );

    }
    

    if ( isset( $_FILES['profile_picture'] ) ) {
        $file_name = $_FILES['profile_picture']['name'];
        $file_tmp = $_FILES['profile_picture']['tmp_name'];
        $file_type = $_FILES['profile_picture']['type'];
        $file_size = $_FILES['profile_picture']['size'];
        if ( $file_tmp && is_uploaded_file( $file_tmp ) ) {
            $upload_dir = WP_CONTENT_DIR . '/uploads/companyinfo/profilepic/';
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_file_name = uniqid() . '.' . $ext; // generate unique name
            $file_path = $upload_dir . $new_file_name;
            if ( move_uploaded_file( $file_tmp, $file_path ) ) {
                $absolute_path =  WP_CONTENT_DIR . '/uploads/companyinfo/profilepic/';
                $upload_dir = wp_upload_dir();
                $relative_path = str_replace($upload_dir['basedir'], '', $absolute_path);
                $relative_path = ltrim($relative_path, '/');
                update_post_meta( $post_id, 'profile_picture','/wp-content/uploads/'. $relative_path.$new_file_name );
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "No file selected.";
        }
    }
    
    $fields = array(
        'location',
        'date',
       
        
    );
    
    foreach ( $fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }

 
}, 10, 2 );

// Add custom fields meta box
add_action( 'add_meta_boxes_companyinfo', function() {
    add_meta_box(
        'companyinfo-custom-fields',
        __( 'companyinfo Custom Fields', 'textdomain' ),
        function( $post ) {
            wp_nonce_field( 'companyinfo_custom_fields', 'companyinfo_custom_fields_nonce' );
            $location = get_post_meta( $post->ID, 'location', true );
            $date = get_post_meta( $post->ID, 'date', true );
            $pincode = get_post_meta( $post->ID, 'pincode', true );
            $professional_summary = get_post_meta( $post->ID, 'professional_summary', true );
            ?>

        </div>
        <div class="maincompanyinfo">
            <div class="avatar-upload">
                <div class="avatar-edit">
                    <label for="profile_picture"><?php _e( 'Profile Picture:', 'textdomain' ); ?></label>
                    <input type="file" id="profile_picture" name="profile_picture" value="<?php echo esc_attr(get_site_url('/') . $profile_picture ); ?>">
                </div>
                <div class="avatar-preview">
                    <div id="imagePreview" class="avtarimg">
                        <img src="<?php echo esc_attr(get_site_url('/') . $profile_picture ); ?>" alt="">
                    </div>
                </div>
            </div>
            
        </div>
      
            <div class="maininpjbplu">
            <label for="pincode"><?php _e( 'Pincode:', 'textdomain' ); ?></label>
            <input type="number" id="pincode" name="pincode" value="<?php echo esc_attr( $pincode ); ?>">
            </div>
            <div class="maininpjbplu">
            <label for="pincode"><?php _e( 'Pincode:', 'textdomain' ); ?></label>
            <input type="number" id="pincode" name="pincode" value="<?php echo esc_attr( $location ); ?>">
            </div>
            </div>
        </div>
            <?php 

        },
        'companyinfo',
        'normal',
        'high'
    );
} );












